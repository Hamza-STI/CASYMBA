# CASYMBA

CASYMBA is a symbolic mathematics program for TI calculators.

The project includes tools for:
- Symbolic simplification
- Derivatives and integrals
- Solving equations and differential equations
- Polynomial operations, including expansion and factorisation
- Numerical and symbolic calculations

## Language

The program's console messages are in English. Calculator function aliases
may still include French names for compatibility with the original project.

## Source

The source code is located in the `src` directory. Build instructions and
project configuration are provided in the makefile and `CMakeLists.txt`.
